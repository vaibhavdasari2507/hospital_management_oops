create
    definer = root@localhost function changename() returns varchar(45) deterministic
begin
declare rollno varchar(45);
set rollno = 'S20200010217';
update customer set customername=rollno where customername='Smith';
return 'Changed the name';
end;

