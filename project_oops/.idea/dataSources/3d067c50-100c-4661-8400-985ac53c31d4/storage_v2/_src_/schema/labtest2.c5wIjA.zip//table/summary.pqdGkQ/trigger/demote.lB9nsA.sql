create definer = root@localhost trigger Demote
    after delete
    on summary
    for each row
begin 
declare BookType varchar(45);
set BookType = old.TypeOfBook;
update LibGen_S20200010217 set promoted = false where TypeOfBook=BookType;
end;

