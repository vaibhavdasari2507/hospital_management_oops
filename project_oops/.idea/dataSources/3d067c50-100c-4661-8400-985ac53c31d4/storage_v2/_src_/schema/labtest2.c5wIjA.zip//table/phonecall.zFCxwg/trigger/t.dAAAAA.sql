create definer = root@localhost trigger t
    after insert
    on phonecall
    for each row
begin

declare p varchar(45);
declare cf int;
declare pps int;
declare secs int;
declare amt int;

select plan into p from customer where ID=new.ID;
select ConnectionFee into cf from baseplan where code = p;
select PricePerSecond into pps from baseplan where code = p;
set secs = new.seconds;
set amt= pps*secs + cf;
insert into bill values(new.ID,MONTH(curdate()),YEAR(curdate()),amt) on duplicate key update amount = amount+amt;
end;

