create
    definer = root@localhost procedure raise_loan(IN amt double, IN acc int)
begin 
if amt>1000000 then
select 'Loan amount more than 10 lakhs.';
else 
update BankCustomer set loan=amt where accNum=acc;
end if;
end;

